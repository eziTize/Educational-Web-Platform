<?php

namespace App\Http\Controllers\Frontweb;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Transformers\{
    TeacherTransformer
};
use App\User;

class TeachersController extends Controller
{
    /**
     * Show the application landing page.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $userRoleTeacher = User::role('teacher')->get();
        $teachers = $this->transformerCollection($userRoleTeacher,new TeacherTransformer(),['categories','accomplishments','extras']);
        return view('all-coaches.coaches-wrapper',[
            'teachers'=>$teachers
        ]);
    }
}
