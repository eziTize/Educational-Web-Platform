<?php

namespace App\Http\Controllers\Frontweb;

use App\VideoSession;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Transformers\{
    TeacherTransformer,
    ZoneTransformer,
    ProfileVisibilityTransformer,
    ProfileLanguageTransformer,
    ProfileCategoryTransformer,
    ProfileCertificationTransformer,
    ProfileAccomplishmentTransformer,
    TeacherSkillTransformer as ProfileSkillTransformer,
};
use App\User;
use App\Models\{
    Zone,
    TeacherSkill as ProfileSkill,
    ProfileVisibility,
    ProfileLanguage,
    ProfileCategory,
    ProfileAccomplishment,
    ProfileDescription,
    ProfileExtra,
    ProfileCertification,
};
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\TeacherRequests\{
    StoreTeacherContactSettings,
    StoreTeacherProfileSettings
};

class TeacherProfileController extends Controller
{
    public function ContactSettings(){
        try {
            $zone = Zone::all();
            $user = User::findOrFail(Auth::id());
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $th) {
            abort(403);
        }
        $timezones = $this->transformerCollection($zone,new ZoneTransformer());
        $teacher = $this->transformerItem($user,new TeacherTransformer());
        return view('coach-profile-settings.contact-info',[
            'timezones'=>$timezones['data'],
            'teacher'=>$teacher
        ]);
    }

    public function ContactSettingsUpdate(StoreTeacherContactSettings $request){
        try {
            $user = User::findOrFail(Auth::id());
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $th) {
            abort(403);
        }
        $validated = $request->validated();

        $data['name']=$validated['name'];
        $data['last_name']=$validated['last_name'];
        $data['email']=$validated['email'];
        $data['contact_number']=$validated['contact_number'];
        $data['zone_id']=$validated['zone_id'];
        $data['address']=$validated['address'];

        $result = $user->update($data);
        if($result){
            return redirect()->route('teacher.settings.index')->with('action_success','Information Updated Successfully');
        }else{
            return redirect()->route('teacher.settings.index')->with('action_fail','Something went wrong! please try again later');
        }
    }

    public function ProfileSettings(){
        try {
            $user = User::findOrFail(Auth::id());
            $profileLanguage = ProfileLanguage::all();
            $profileCategory = ProfileCategory::all();
            $profileSkill = ProfileSkill::all();
            $profileCertification = ProfileCertification::where('User_id', $user->id)->get();
            $profileAccomplishment = ProfileAccomplishment::where('user_id', $user->id)->get();
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $th) {
            abort(403);
        }
        $teacher = $this->transformerItem($user,new TeacherTransformer(),['visibility','languages', 'skills', 'categories','accomplishments','extras']);
        $languages = $this->transformerCollection($profileLanguage,new ProfileLanguageTransformer());
        $skills = $this->transformerCollection($profileSkill,new ProfileSkillTransformer());
        $categories = $this->transformerCollection($profileCategory,new ProfileCategoryTransformer());
        $certification = $this->transformerCollection($profileCertification,new ProfileCertificationTransformer());
        $accomplishments = $this->transformerCollection($profileAccomplishment,new ProfileAccomplishmentTransformer());
        return view('coach-profile-settings.profile-settings',[
            'teacher'=>$teacher,
            'languages'=>$languages,
            'skills'=>$skills,
            'categories'=>$categories,
            'accomplishments'=>$accomplishments,
            'certification'=>$certification,
        ]);
    }

    public function ProfileSettingsUpdate(StoreTeacherProfileSettings $request){
        try {
            $user = User::findOrFail(Auth::id());
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $th) {
            abort(403);
        }
        $validated = $request->validated();

        //Updating the profile visibility
        $visibility = ProfileVisibility::updateOrCreate(
            ['user_id' => Auth::id()],
            ['visibility_type'=>$request->teacher_profile_visibility]
        );

        //Updating the profile visibility
        $extra = ProfileExtra::updateOrCreate(
            ['user_id' => Auth::id()],
            [
                'travel_willingness'=>$request->teacher_travel_willingness,'average_price'=>$request->teacher_average_price
            ]
        );

        if($request->profile_image != null){
            $user->clearMediaCollection('profile-image-collection');
            $media = $user->addMediaFromRequest('profile_image')->toMediaCollection('profile-image-collection');
        }
        if($request->banner_image != null){
            $user->clearMediaCollection('profile-banner-collection');
            $media = $user->addMediaFromRequest('banner_image')->toMediaCollection('profile-banner-collection');
        }

        // Updating the profile linked description...
        $description = ProfileDescription::updateOrCreate(
            ['user_id' => Auth::id()],
            ['description'=>$request->description]
        );
        $user->profile_description()->save($description);

        //Updating the profile linked categories..
        $categories = array();
        $selected_categories = $request->teacher_profile_categories;
        if($selected_categories!=null){
            foreach ($selected_categories as $selected_category) {
                // Retrieve category by name, or create it if it doesn't exist...
                $details = ProfileCategory::firstOrCreate(
                    ['name' => $selected_category],
                    ['slug'=>Str::slug($selected_category)]
                );
                \array_push($categories,$details->id);
            }
            $user->profile_categories()->sync($categories);
        }

        //Updating the profile linked languages..
        $languages = array();
        $selected_languages = $request->teacher_profile_languages;
        if($selected_languages!=null){
            foreach ($selected_languages as $selected_language) {
                // Retrieve category by name, or create it if it doesn't exist...
                $details = ProfileLanguage::firstOrCreate(
                    ['name' => $selected_language],
                    ['slug'=>Str::slug($selected_language)]
                );
                \array_push($languages,$details->id);
            }
            $user->profile_languages()->sync($languages);
        }
       
        //deleting the old accomplishments first and attaching it with new...
        $user->profile_accomplishments()->delete();
        $selected_accomplishments = $request->teacher_profile_accomplishments;
        if($selected_accomplishments!=null){
            foreach ($selected_accomplishments as $selected_accomplishment) {
                // Retrieve accomplishment by title and user_id, or create it if it doesn't exist...
                $details = ProfileAccomplishment::firstOrCreate(
                    ['title' => $selected_accomplishment,'user_id' => Auth::id()],
                    ['slug'=>Str::slug($selected_accomplishment)]
                );
                $user->profile_accomplishments()->save($details);
            }
        }
        return redirect()->route('teacher.profile.settings')->with('action_success','Information Updated Successfully');
    }

    public function show($id){
        try {
            $user = User::findOrFail($id);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $th) {
            abort(403);
        }
        if(!$user->hasRole('teacher')){
            return redirect('/');
        }
        $teacher = $this->transformerItem($user,new TeacherTransformer(),['languages', 'categories','accomplishments','skills', 'certification']);
        return view('coach-details.details-wrapper',[
            'teacher'=>$teacher
        ]);
    }

    public function vsess(){

        $vsess = VideoSession::where('user_id', auth()->user()->id)->get();

        return View('coach-profile-settings.sessions',[
            'vsess'=>$vsess
        ]);

    }
}
