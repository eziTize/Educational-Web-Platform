<?php

namespace App\Http\Controllers\Frontweb;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

use App\User;
use App\Models\{
    TeacherSkill
};
use App\Transformers\{
    TeacherTransformer,
    TeacherSkillTransformer
};

use Illuminate\Support\Facades\Auth;

class ServicesController extends Controller
{
    public function index($id=null){
        try {
            $user = User::findOrFail(Auth::id());
            $singleSkill = ($id!=null) ? TeacherSkill::findOrFail($id) : null ;
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $th) {
            abort(403);
        }
        $teacher = $this->transformerItem($user,new TeacherTransformer(),['skills']);

        //If skill ID is provided and is valid return it with the details of that skill
        $singleSkill = ($singleSkill!=null) ? $this->transformerItem($singleSkill,new TeacherSkillTransformer()) : $singleSkill ;

        return view('coach-skills-packages.details-wrapper',[
            'teacher'=>$teacher,
            'singleSkill'=>$singleSkill,
        ]);
    }

    public function skillsStore(Request $request){
        $validator = Validator::make($request->all(), [
            'title' => 'required|max:255',
            'description' => 'required',
            'price'=> 'required|integer|min:1|max:10000',
        ]);
        if ($validator->fails()) {
            return redirect()->route('teacher.services.index',['openModel'=>'createSkillModal'])
                    ->withErrors($validator)
                    ->withInput();
        }
        $skill = TeacherSkill::create([
            'user_id'=>Auth::id(),
            'title'=>$request->title,
            'description'=>$request->description,
            'price'=>$request->price
        ]);
        if($skill){
            return redirect()->route('teacher.services.index')->with('action_success','Information Updated Successfully');
        }else{
            return redirect()->route('teacher.services.index')->with('action_fail','Something went wrong! please try again later');
        }
    }

    public function skillsUpdate(Request $request,$id){
        try {
            $teacherSkill = TeacherSkill::findOrFail($id);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $th) {
            abort(403);
        }
        $validator = Validator::make($request->all(), [
            'title' => 'required|max:255',
            'description' => 'required',
            'price'=> 'required|integer|min:1|max:10000',
        ]);
        if ($validator->fails()) {
            return redirect()->route('teacher.skills.update',['id'=>$id])
                    ->withErrors($validator)
                    ->withInput();
        }
        $skill = $teacherSkill->update([
            'title'=>$request->title,
            'description'=>$request->description,
            'price'=>$request->price
        ]);
        if($skill){
            return redirect()->route('teacher.services.index')->with('action_success','Information Updated Successfully');
        }else{
            return redirect()->route('teacher.services.index')->with('action_fail','Something went wrong! please try again later');
        }
    }
}
