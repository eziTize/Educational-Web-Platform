<?php
   namespace App\Http\Controllers;

   use Illuminate\Http\Request;

   use Auth;
   use App\VideoSession;
   use Twilio\Rest\Client;
   use Twilio\Jwt\AccessToken;
   use Illuminate\Support\Str;
   use Twilio\Jwt\Grants\VideoGrant; 

class twilioController extends Controller
{

	protected $sid;
	protected $token;
	protected $key;
	protected $secret;


	public function __construct()
	{
	   $this->sid = env('TWILIO_ACCOUNT_SID'); //config('services.twilio.sid');
	   $this->key = env('TWILIO_API_KEY_SID');
	   $this->secret = env('TWILIO_API_KEY_SECRET'); //config('services.twilio.secret');
	   $this->token = "61723bba016c0cf52be0789bd3cb37b7";
	}


	/*
    |------------------------------------------------------------------
    |   Video Rooms Index
    |------------------------------------------------------------------
    */

	public function index()
	{
	   
	   $rooms = VideoSession::where('user_id', auth()->user()->id)->get();

	   /*$rooms = [];
	   try {
	       $client = new Client($this->sid, $this->token);
	       $allRooms = $client->video->rooms->read([]);

	        $rooms = array_map(function($room) {
	           return $room->uniqueName;
	        }, $allRooms);

	   } catch (Exception $e) {
	       echo "Error: " . $e->getMessage();
	   }*/

	   return view('twilio.index', ['rooms' => $rooms]);
	}


	/*
    |------------------------------------------------------------------
    |   Video Rooms Create
    |------------------------------------------------------------------
    */
	public function createRoom(Request $request)
	{
	   $client = new Client($this->sid, $this->token);

	   $v_session = new VideoSession;

	   //if($v_session->validate($request->all())){
         //   return back()->withErrors($v_session->validate($request->all()))->withInput();
       // }

	   $v_session->user_id =  auth()->user()->id;
	   $v_session->session_name = 'session_'.uniqid().rand(99,1000).auth()->user()->id;
	   $v_session->session_pass =  Str::uuid();
	   $v_session->save();


	   //$exists = $client->video->rooms->read([ 'uniqueName' => $v_session->session_name]);

	   //if (empty($exists)) {
	       $client->video->rooms->create([
	           'uniqueName' => $v_session->session_name,
	           'type' => 'group',
	           'recordParticipantsOnConnect' => false
	       ]);

	       \Log::debug("Session Created: ".$v_session->session_name);
	   //}

	  // return redirect()->action('twilioController@joinRoom', [
	      // 'roomName' => $request->roomName
	   //]);

	      return redirect()->action('twilioController@index')->with('room_session_created',[
	       'roomLink' => url('/').'/video-session/join/'.$v_session->session_name,
	       'roomPass' => $v_session->session_pass,
	   	]);
	}


	/*
    |------------------------------------------------------------------
    |   Join Video Session
    |------------------------------------------------------------------
    */
	public function joinRoom(Request $request, $roomName)
	{

	   $identity = 'ct_'.auth()->user()->id.'_'.uniqid();
	   $user_name = auth()->user()->name;
	   $v_session = VideoSession::where('session_name', $roomName)->firstOrFail();

	   if(VideoSession::where('session_name', $roomName)->count() > 0){


	   	if($request->get('s_pass')){

	   		if($request->get('s_pass') ==  $v_session->session_pass){

	   			\Log::debug("joined with identity: $identity");
		   		$token = new AccessToken($this->sid, $this->key, $this->secret, 3600, $identity);
		   		$videoGrant = new VideoGrant();
		   		$videoGrant->setRoom($roomName);
		   		$token->addGrant($videoGrant);
		   		return view('twilio.room', [ 'accessToken' => $token->toJWT(), 'roomName' => $roomName, 'user_name' => $user_name ])->with('action_success','Session Joined Successfully.');
	   		}

	   		else{

	   			return view('twilio.index2', [
	       's_enter' => 'Enter Session Pass to continue.',
	       's_invalid' => 'Session pass invalid.',
	       'roomName'  => $v_session->session_name,
	   	]);
	   		}
	   	 }

	   	else{

	   			return view('twilio.index2', [
	       's_enter' => 'Enter Session Pass to continue.',
	       's_invalid' => '',
	       'roomName'  => $v_session->session_name,
	   	]);
	   } 	
	   		
	  }

	    return view('twilio.index')->with('fail_message', 'Session does not exist.');

	   
	}

}