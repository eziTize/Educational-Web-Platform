<?php
namespace App\Models\TraitsRelationships;

trait UserRelationships{
    
    /**
     * Get the visibility status
     */
    public function profile_visibility()
    {
        return $this->hasOne('App\Models\ProfileVisibility');
    }

    /**
     * Get the categories associated with user profile.
     */
    public function profile_languages()
    {
        return $this->belongsToMany('App\Models\ProfileLanguage');
    }

    /**
     * Get the users profile description
     */
    public function profile_description()
    {
        return $this->hasOne('App\Models\ProfileDescription');
    }

    /**
     * Get the categories associated with user profile.
     */
    public function profile_categories()
    {
        return $this->belongsToMany('App\Models\ProfileCategory');
    }

    /**
     * Get the accomplishments associated with user profile.
     */
    public function profile_accomplishments()
    {
        return $this->hasMany('App\Models\ProfileAccomplishment');
    }

    /**
     * Get the accomplishments associated with user profile.
     */
    public function profile_extras()
    {
        return $this->hasOne('App\Models\ProfileExtra');
    }

    /**
     * Get the skills associated with user profile.
     */
    public function skills()
    {
        return $this->hasMany('App\Models\TeacherSkill');
    }

    public function certification()
    {
        return $this->hasMany('App\Models\ProfileCertification');
    }
}