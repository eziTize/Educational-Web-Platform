<?php
namespace App;

//use Validator;
use Illuminate\Database\Eloquent\Model;

class Payout extends Model
{

        protected $table = "payouts";
        protected $fillable = [
             'name', 'ac_type', 'ac_no', 'amount'
        ];
 }
